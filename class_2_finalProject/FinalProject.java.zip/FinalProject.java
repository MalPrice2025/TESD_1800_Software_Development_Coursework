package hellofx;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.geometry.*;
import javafx.animation.*;
import javafx.util.Duration;
import java.util.Random;

public class Main extends Application {
    private Stage mainStage;

    @Override
    public void start(Stage stage) {
        mainStage = stage;

        Button playTicTacToe = new Button("Play Tic Tac Toe");
        Button playCoinCollector = new Button("Play Coin Collector");
        Button playCardMatch = new Button("Play Card Match");

        playTicTacToe.setOnAction(e -> {
            TicTacToe game = new TicTacToe();
            mainStage.setScene(game.getScene(mainStage));
        });
        playCoinCollector.setOnAction(e -> {
            CoinCollector game = new CoinCollector();
            mainStage.setScene(game.getScene(mainStage));
        });
        playCardMatch.setOnAction(e -> {
            CardMatch game = new CardMatch();
            mainStage.setScene(game.getScene(mainStage));
        });
        VBox menu = new VBox(20, playTicTacToe, playCoinCollector, playCardMatch);
        menu.setAlignment(Pos.CENTER);

        Scene menuScene = new Scene(menu, 500, 400);
        mainStage.setScene(menuScene);
        mainStage.setTitle("Mini Game Menu");
        mainStage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }
}
class CoinCollector {
    private int coins = 0;
    private int speed = 2;
    Slider player = new Slider();

    public Scene getScene(Stage stage) {
        Pane pane = new Pane();
        Circle coin = new Circle(10, Color.GOLD);
        coin.setCenterX(Math.random() * 480 + 10);
        coin.setCenterY(0);
        player.setShowTickLabels(false);
        player.setShowTickMarks(false);
        player.setPrefWidth(480);
        player.setLayoutX(10);
        player.setLayoutY(380);

        Label scoreLabel = new Label("SCORE: 0");
        scoreLabel.setLayoutX(10);
        scoreLabel.setLayoutY(10);

        Button backToMenu = new Button("Back to Menu");
        backToMenu.setLayoutX(400);
        backToMenu.setLayoutY(10);
        backToMenu.setOnAction(e -> {
            coins = 0;
            speed = 2;
            new Main().start(stage);
        });
        pane.getChildren().addAll(coin, player, scoreLabel, backToMenu);

        Timeline timeline = new Timeline(new KeyFrame(Duration.millis(20), e -> {
            coin.setCenterY(coin.getCenterY() + (400.0 / (6000.0 / 20.0)) * speed);
                double playerX = player.getLayoutX() + (player.getValue() / player.getMax()) * player.getWidth();
                double playerY = 380;
                if(coin.getCenterY() >= playerY - 10 && Math.abs(coin.getCenterX() - playerX) < 50){
                    coins++;
                    scoreLabel.setText("SCORE" + coins + ".");
                    coin.setCenterY(0);
                    coin.setCenterX(Math.random() * 480 + 10);
                    if(coins % 25 == 0) {
                        speed++;
                    }
                }
                if (coin.getCenterY() > 400) {
                    coin.setCenterY(0);
                    coin.setCenterX(Math.random() * 480 + 10);
            }
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
        return new Scene(pane, 500, 400);
    }
}
class CardMatch {
    private Button firstCard = null;
    private Button secondCard = null;
    private int matches;
    private String[] values = {"1", "1", "2", "2", "3", "3", "4", "4"};

    public Scene getScene(Stage stage) {
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        shuffle(values);
        Button[] cards = new Button[8];
        for (int i = 0; i < 8; i++) {
            Button card = new Button("?");
            card.setPrefSize(60, 60);
            String value = values[i];

            card.setOnAction(e -> handleCardClick(card, value));

            cards[i] = card;
            grid.add(card, i % 4, i / 4);
        }
        Button back = new Button("Back to Menu");
        back.setOnAction(e -> new Main().start(stage));

        VBox layout = new VBox(20, grid, back);
        layout.setAlignment(Pos.CENTER);
        return new Scene(layout, 400, 300);
    }
    private void handleCardClick(Button card, String value) {
        card.setText(value);
        if (firstCard == null) {
            firstCard = card;
        } else if (secondCard == null && card != firstCard) {
            secondCard = card;

            if (firstCard.getText().equals(secondCard.getText())) {
                matches++;
                firstCard = null;
                secondCard = null;
            } else {
                Timeline pause = new Timeline(new KeyFrame(Duration.seconds(0.5), e -> {
                    firstCard.setText("?");
                    secondCard.setText("?");
                    firstCard = null;
                    secondCard = null;
                }));
                pause.play();
            }
        }
    }
    private void shuffle(String[] cards) {
        Random rand = new Random();
        for (int i = cards.length - 1; i > 0; i--) {
            int j = rand.nextInt(i + 1);
            String temp = cards[i];
            cards[i] = cards[j];
            cards[j] = temp;
        }
    }
}
class TicTacToe {
    private char currentPlayer = 'X';
    private Button[][] buttons;
    private Label statusLabel = new Label("Player X's turn");
    private int boardSize = 3;

    public Scene getScene(Stage stage) {
        VBox layout = new VBox(20);
        layout.setAlignment(Pos.CENTER);

        GridPane grid = createBoard();

        Button back = new Button("Back to Menu");
        back.setOnAction(e -> new Main().start(stage));

        layout.getChildren().addAll(statusLabel, grid, back);

        return new Scene(layout, 500, 500);
    }
    private GridPane createBoard() {
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        buttons = new Button[boardSize][boardSize];
        for (int r = 0; r < boardSize; r++) {
            for (int c = 0; c < boardSize; c++) {
                Button btn = new Button("");
                btn.setPrefSize(400.0 / boardSize, 400.0 / boardSize);
                buttons[r][c] = btn;
                btn.setOnAction(e -> makeMove(btn));
                grid.add(btn, c, r);
            }
        }
        return grid;
    }
    private void makeMove(Button btn) {
        if (!btn.getText().equals("")) return;
        btn.setText(String.valueOf(currentPlayer));
        if (checkWin()) {
            statusLabel.setText(currentPlayer + " wins!");
            nextRound();
            return;
        }
        if (isBoardFull()) {
            statusLabel.setText("It's a draw!");
            nextRound();
            return;
        }
        currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
        statusLabel.setText("Player " + currentPlayer + "'s turn");
    }
    private boolean checkWin() {
        for (int i = 0; i < boardSize; i++) {
            boolean rowWin = true;
            boolean colWin = true;
            for (int j = 0; j < boardSize - 1; j++) {
                if (!buttons[i][j].getText().equals(buttons[i][j + 1].getText()) ||
                    buttons[i][j].getText().equals("")) rowWin = false;
                if (!buttons[j][i].getText().equals(buttons[j + 1][i].getText()) ||
                    buttons[j][i].getText().equals("")) colWin = false;
            }
            if (rowWin || colWin) return true;
        }
        boolean diag1 = true, diag2 = true;
        for (int i = 0; i < boardSize - 1; i++) {
            if (!buttons[i][i].getText().equals(buttons[i + 1][i + 1].getText()) ||
                buttons[i][i].getText().equals("")) diag1 = false;
            if (!buttons[i][boardSize - 1 - i].getText().equals(buttons[i + 1][boardSize - 2 - i].getText()) ||
                buttons[i][boardSize - 1 - i].getText().equals("")) diag2 = false;
        }
        return diag1 || diag2;
    }
    private boolean isBoardFull() {
        for (int r = 0; r < boardSize; r++)
            for (int c = 0; c < boardSize; c++)
                if (buttons[r][c].getText().equals("")) return false;
        return true;
    }
    private void nextRound() {
            boardSize++;
            if (boardSize > 7) boardSize = 3;
            resetBoard();
    }
    private void resetBoard() {
        VBox parent = (VBox) statusLabel.getParent();
        parent.getChildren().remove(1);
        GridPane newGrid = createBoard();
        parent.getChildren().add(1, newGrid);

        statusLabel.setText("Player X's turn");
        currentPlayer = 'X';
    }
}