class TestMyInteger {
	public static void main(String[] args) {
		MyInteger first = new MyInteger(26);
		
		System.out.println("First integer, even is " + first.isEven());
		System.out.println("First integer, odd is " + first.isOdd());
		System.out.println("First integer, prime is " + first.isPrime());
		
		System.out.println("Is 15 even? " + MyInteger.isEven(15));
		System.out.println("Is 13 odd? " + MyInteger.isOdd(13));
		System.out.println("Is 14 prime? " + MyInteger.isPrime(14));
		
		System.out.println("Is the first integer equal to 5? " + first.equals(5));
		
		char[] numbers = {'6','7','6','7'};
	System.out.println("characters converted to int value: " + MyInteger.parseInt(numbers));
	System.out.println("String converted to int value: " + MyInteger.parseInt("456"));
	
	
	}
}

class MyInteger {
	private int value;
	
	MyInteger(int newvalue) {
		value = newvalue;
	}
	int getValue() {
		return value;
	}
	boolean isEven() {
		return value %2 == 0;
	}
	boolean isOdd() {
		return value %2 != 0;
	}
	boolean isPrime() {
		if(value <= 1)
		return false;
		for(int i = 2; i <= value / 2; i++) {
			if(value % i == 0)
			return false;
		}
		return true;
	}
	static boolean isEven(int num) {
		return num %2 == 0;
	}
	static boolean isOdd(int num) {
		return num %2 != 0;
	}
	static boolean isPrime(int num) {
		if(num <= 1)
		return false;
		for(int i = 2; i <= num / 2; i++) {
			if(num % i == 0)
			return false;
		}
		return true;
	}
	static boolean isEven(MyInteger num) {
		return num.isEven();
	}
	static boolean isOdd(MyInteger num) {
		return num.isOdd();
	}
	static boolean isPrime(MyInteger num) {
		return num.isPrime();
	}
	boolean equals(int num) {
		return value == num;
	}
	boolean equals(MyInteger num) {
		return value == num.getValue();
	}
	static int parseInt(char[] numList) {
		int result = 0;
		for(int i = 0; i <numList.length; i++) {
			if (numList[i] >= '0' && numList[i] <= '9') {
				result = result * 10 + (numList[i] - '0');
			}
		}
		return result;
	}
	static int parseInt(String string) {
		int result = 0;
		for(int i = 0; i< string.length(); i++) {
			result = result * 10 + (string.charAt(i) - '0');
		}
		return result;
	}
}