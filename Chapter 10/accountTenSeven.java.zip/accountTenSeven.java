import java.util.*;

public class accountTenSeven {
    public static void main(String[] agrs) {
    Scanner scan = new Scanner(System.in);
    accountMod[] accounts = new accountMod[10];
    for(int i = 0; i < accounts.length; i++) {
        accounts[i] = new accountMod(i, 100.0);
        
        accounts[i].setAnnualInterestRate(4.5);
        }
            while (true) {
                int userID;
                boolean match = false;
                
                do {
                    System.out.println("Enter account ID: ");
                    userID = scan.nextInt();
                    match = false;
                    for(int i = 0; i < accounts.length; i++) {
                        if (accounts[i].getID() == userID) {
                            match = true;
                            break;
                        }
                    }
                    if (!match) {
                        System.out.println("Invalid -X- Please try again");
                    }
                }while (!match);
        
        int choice;
        do {
            System.out.println();
            System.out.println("Please select one of the following options");
            System.out.println("1) View Current Balance");
            System.out.println("2) Withdraw Money");
            System.out.println("3) Deposit Money");
            System.out.println("4) Exit to Main");
            choice = scan.nextInt();
            
            if (choice == 1) {
                System.out.println("Account balance: " + accounts[userID].getBalance());
            } else if (choice == 2) {
                System.out.println("Enter withdraw amount: ");
                double amount = scan.nextDouble();
                accounts[userID].withdraw(amount);
                System.out.printf("New updated balance - $%.2f%n", accounts[userID].getBalance());
            } else if (choice == 3) {
                System.out.println("Enter deposit amount: ");
                double amount = scan.nextDouble();
                accounts[userID].deposit(amount);
                System.out.printf("New updated balance - $%.2f%n", accounts[userID].getBalance());
            }
            }while (choice != 4);
        }
    }
}
class accountMod {
    private int id;
    private double balance;
    private double annualInterestRate;
    private Date dateCreated;
    
    public accountMod() {
        id = 0;
        balance = 0.0;
        annualInterestRate = 0.0;
        dateCreated = new Date();
    }
    public accountMod(int newID, double newBalance) {
        id = newID;
        balance = newBalance;
        annualInterestRate = 0.0;
        dateCreated = new Date();
    }
    public int getID() {
        return id;
    }
    public void setID(int newID) {
        id = newID;
    }
    public double getBalance() {
        return balance;
    }
    public void setBalance(double newBalance) {
        balance = newBalance;
    }
    public double getAnnualInterestRate() {
        return annualInterestRate;
    }
    public void setAnnualInterestRate(double newAnnualInterestRate) {
        annualInterestRate = newAnnualInterestRate;
    }
    public Date getDateCreated() {
        return dateCreated;
    }
    public double getMonthlyInterestRate() {
        return (annualInterestRate/100) /12;
    }
    public double getMonthlyInterest() {
        return balance * getMonthlyInterestRate();
    }
    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
        }
    }
    public void deposit(double amount) {
        balance = balance + amount;
    }
}