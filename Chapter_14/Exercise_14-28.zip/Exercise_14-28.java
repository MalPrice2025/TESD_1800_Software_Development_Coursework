package hellofx;

import java.util.*;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class Main extends Application {
    @Override 
    public void start(Stage primaryStage) {
        ClockPane clock = new ClockPane();
        String timeString = clock.getHour() + ":" + clock.getMinute() + ":" + clock.getSecond();
        Label lblCurrentTime = new Label(timeString);
        
        BorderPane pane = new BorderPane();
        pane.setCenter(clock);
        pane.setBottom(lblCurrentTime);
        BorderPane.setAlignment(lblCurrentTime, Pos.TOP_CENTER);
        
        Scene scene = new Scene(pane, 250, 250);
        primaryStage.setTitle("DisplayClock");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    public class ClockPane extends Pane {
        Random random = new Random();
        private int rhour;
        private int rminute;
        private int rsecond;
        private boolean hourHandVisible;
        private boolean minuteHandVisible;
        private boolean secondHandVisible;

        private double w = 250, h = 250;

        public ClockPane(){
            rhour = random.nextInt(12);
            rminute = random.nextBoolean() ? 30 : 0;
            rsecond = random.nextInt(60);
            setTime();
        }
        public int getHour(){
            return rhour;
        }
        public int getMinute(){
            return rminute;
        }
        public int getSecond(){
            return rsecond;
        }
        public void setHour(int rhour){
            this.rhour = rhour;
            paintClock();
        }
        public void setMinute(int rminute){
            this.rminute = rminute;
            paintClock();
        }
        public void setSecond(int rsecond){
            this.rsecond = rsecond;
            paintClock();
        }
        public double getW(){
            return w;
        }
        public double getH(){
            return h;
        }
        public void setW(double w){
            this.w = w;
            paintClock();
        }
        public void setH(double h){
            this.h = h;
            paintClock();
        }
        public boolean getHourHandVisible(){
            return hourHandVisible;
        }
        public boolean getMinuteHandVisible(){
            return minuteHandVisible;
        }
        public boolean getSecondHandVisible(){
            return secondHandVisible;
        }
        public void setHourHandVisible(boolean hourHandVisible, Line hLine){
            if (rhour < 0) {
                hLine.setOpacity(0.0);
            } else { 
                hLine.setOpacity(1.0);
            }
        }
        public void setMinuteHandVisible(boolean minuteHandVisible, Line mLine){
            if (rminute < 0) {
                mLine.setOpacity(0.0);
            } else {
                mLine.setOpacity(1.0);
            }
        }
        public void setSecondHandVisible(boolean secondHandVisible, Line sLine){
            if (rsecond > 0) {
                sLine.setOpacity(0.0);
            } else {
                sLine.setOpacity(1.0);
            }
        }
        public void setTime(){
            rhour = random.nextInt(12);
            rminute = random.nextBoolean() ? 30 : 0;
            rsecond = random.nextInt(60);
            paintClock();
        }
        protected void paintClock(){
            double clockRadius = Math.min(w, h) * 0.8 * 0.5;
            double centerX = w/2;
            double centerY = h/2;

            Circle circle = new Circle(centerX, centerY, clockRadius);
            circle.setFill(Color.WHITE);
            circle.setStroke(Color.BLACK);
            circle.setStrokeWidth(2.5);
            Text t1 = new Text(centerX - 5, centerY - clockRadius + 12, "12");
            Text t2 = new Text(centerX - clockRadius + 3, centerY + 5, "9");
            Text t3 = new Text(centerX + clockRadius - 10, centerY + 3, "3");
            Text t4 = new Text(centerX - 3, centerY + clockRadius - 3, "6");

            double sL = clockRadius * 0.8;
            double secX = centerX + sL * Math.sin(rsecond * (2 * Math.PI / 60));
            double secY = centerY + sL * Math.cos(rsecond * (2 * Math.PI / 60));
            Line sLine = new Line(centerX, centerY, secX, secY);
            sLine.setStroke(Color.RED);
            setSecondHandVisible(true, sLine);

            double mL = clockRadius * 0.65;
            double minX = centerX + mL * Math.sin(rminute * (2 * Math.PI / 60));
            double minY = centerY - mL * Math.cos(rminute * (2 * Math.PI / 60));
            Line mLine = new Line(centerX, centerY, minX, minY);
            mLine.setStroke(Color.BLUE);
            setMinuteHandVisible(true, mLine);

            double hL = clockRadius * 0.5;
            double hourX = centerX + hL * Math.sin((rhour % 12 + rminute / 60.0) * (2 * Math.PI / 12));
            double hourY = centerY - hL * Math.cos((rhour % 12 - rminute / 60.0) * (2 * Math.PI / 12));
            Line hLine = new Line(centerX, centerY, hourX, hourY);
            hLine.setStroke(Color.GREEN);
            setHourHandVisible(true, hLine);

            getChildren().clear();
            getChildren().addAll(circle, t1, t2, t3, t4, sLine, mLine, hLine);
        }
    }
}