package hellofx;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.*;
import javafx.scene.text.*;
import javafx.scene.input.*;
import javafx.scene.control.*;
import javafx.geometry.*;

public class Main extends Application {

    BorderPane getPane() {
    Media Media_URL = new Media("https://liveexample.pearsoncmg.com/common/audio/anthem/anthem0.mp3");
    MediaPlayer player = new MediaPlayer(Media_URL);
    VBox vbox = new VBox(10);
    vbox.setAlignment(Pos.CENTER);
    Text text = new Text(50,50,"---");
    Font textFont = new Font("Times New Roman", 55);
    text.setFont(textFont);

    BorderPane paneForNum = new BorderPane();
    paneForNum.setPadding(new Insets(5,5,5,5));
    paneForNum.setStyle("-fx-border-color: black");
    paneForNum.setLeft(new Label("Enter Countdown: "));

    TextField tbox = new TextField();
    tbox.setStyle("-fx-text-fill: black");
    tbox.setAlignment(Pos.BASELINE_RIGHT);
    paneForNum.setCenter(tbox);

    BorderPane mainPane = new BorderPane();
    mainPane.setTop(paneForNum);
    mainPane.setCenter(vbox);

    tbox.setOnKeyPressed(e -> {
        if (e.getCode() == KeyCode.ENTER){
            text.setText(tbox.getText());
            int num = Integer.parseInt(tbox.getText());
            Timeline tt = new Timeline();
            for(int i = num; i > 0; i--) {
                int current = i;
                tt.getKeyFrames().add(new KeyFrame(Duration.seconds(num - i), ev -> {
                    Stage newStage= new Stage();
                    BorderPane newBPane = new BorderPane();
                    newBPane.setPadding(new Insets(5,5,5,5));
                    newBPane.setStyle("-fx-border-color: black");
                    Text newText = new Text(String.valueOf(current));
                    newText.setFont(textFont);
                    newBPane.setCenter(newText);
                    BorderPane.setAlignment(newText, Pos.CENTER);
                    Scene newScene = new Scene(newBPane, 200, 200);
                    newStage.setScene(newScene);
                    newStage.setTitle("Exercise16_21");
                    newStage.show();
                    if (current == 0) {
                        player.play();
                    }
                }));
            }
            tt.play();
        }
    });
    return mainPane;
}
    @Override
    public void start(Stage primaryStage) {
    Scene scene = new Scene(getPane(), 200, 200);
    primaryStage.setScene(scene);
    primaryStage.setTitle("Exercise16_21");
    primaryStage.show();
    }
}
