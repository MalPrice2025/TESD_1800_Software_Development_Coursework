package hellofx;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.text.Text;
import javafx.scene.text.Font;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.geometry.Pos;
import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;

public class Main extends Application {
    Text text = new Text(100, 80, "Programming is fun");
    BorderPane mainPane() {
        Font font1 = new Font("Times New Roman", 30);
        text.setFont(font1);
        
        HBox sideToSideButtons = new HBox(20);
        Button bLeft = new Button("<--");
        Button bRight = new Button("-->");
        sideToSideButtons.getChildren().addAll(bLeft, bRight);
        sideToSideButtons.setAlignment(Pos.CENTER);
        sideToSideButtons.setStyle("-fx-border-color: black");
        
        HBox colorButtons = new HBox(20);
        RadioButton bRed = new RadioButton("RED");
        RadioButton bYellow = new RadioButton("YELLOW");
        RadioButton bBlack = new RadioButton("BLACK");
        RadioButton bOrange = new RadioButton("ORANGE");
        RadioButton bGreen = new RadioButton("GREEN");
        colorButtons.getChildren().addAll(bRed, bYellow, bBlack, bOrange, bGreen);
        colorButtons.setAlignment(Pos.CENTER);
        colorButtons.setStyle("-fx-border-color: black");
        
        ToggleGroup groupColorButtons = new ToggleGroup();
        bRed.setToggleGroup(groupColorButtons);
        bYellow.setToggleGroup(groupColorButtons);
        bBlack.setToggleGroup(groupColorButtons);
        bOrange.setToggleGroup(groupColorButtons);
        bGreen.setToggleGroup(groupColorButtons);

        bRed.setOnAction(e -> {
            if (bRed.isSelected()) {
                text.setFill(Color.RED);
                text.setStroke(Color.BLACK);
                text.setStrokeWidth(.25);
            }
        });
        bYellow.setOnAction(e -> {
            if (bYellow.isSelected()) {
                text.setFill(Color.YELLOW);
                text.setStroke(Color.BLACK);
                text.setStrokeWidth(.25);
            }
        });
        bBlack.setOnAction(e -> {
            if (bBlack.isSelected()) {
                text.setFill(Color.BLACK);
                text.setStroke(Color.BLACK);
                text.setStrokeWidth(.25);
            }
        });
        bOrange.setOnAction(e -> {
            if (bOrange.isSelected()) {
                text.setFill(Color.ORANGE);
                text.setStroke(Color.BLACK);
                text.setStrokeWidth(.25);
            }
        });
        bGreen.setOnAction(e -> {
            if (bGreen.isSelected()) {
                text.setFill(Color.GREEN);
                text.setStroke(Color.BLACK);
                text.setStrokeWidth(.25);
            }
        });
        BorderPane pane = new BorderPane();
        pane.setBottom(sideToSideButtons);
        pane.setTop(colorButtons);
        Pane paneForText = new Pane();
        paneForText.getChildren().add(text);
        pane.setCenter(paneForText);

        bLeft.setOnAction(e -> left(bLeft,pane));
        bRight.setOnAction(e -> right(bRight,pane));
        return pane;
    }
    public void left(Button bLeft, BorderPane pane){
        bLeft.setOnAction(e -> {
            if (text.getX() > 0) { text.setX(text.getX() - 10);
            }
        });
    }
    public void right(Button bRight, BorderPane pane){
        bRight.setOnAction(e -> {
            if (text.getBoundsInParent().getMaxX() + 10 <= pane.getWidth()) {
                text.setX(text.getX() + 10);
            }
        });
    }
    @Override
    public void start(Stage primaryStage) throws Exception{
        Scene scene = new Scene(mainPane(), 450, 200);
        primaryStage.setTitle("Exercise_16-1");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}


    