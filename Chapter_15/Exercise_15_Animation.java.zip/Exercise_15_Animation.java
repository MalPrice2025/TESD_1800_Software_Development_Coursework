package hellofx;

import javafx.application.Application;
import javafx.animation.Timeline;
import javafx.animation.PathTransition;
import javafx.animation.FadeTransition;
import javafx.util.Duration;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.shape.*;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class Main extends Application {
        @Override
        public void start(Stage primaryStage){
            Pane pane = new Pane();
            Rectangle r1 = new Rectangle(0, 0, 25, 50);
            r1.setFill(Color.PURPLE);
            r1.setStroke(Color.BLACK);
            FadeTransition ft = new FadeTransition(Duration.millis(2000),r1);
            ft.setFromValue(1.0);
            ft.setToValue(0.1);
            ft.setCycleCount(Timeline.INDEFINITE);
            ft.setAutoReverse(true);
            ft.play();

        Polygon pentagon = new Polygon();
        double centerX = 150;
        double centerY = 125;
        double radius = 100;
        pentagon.setFill(Color.WHITE);
        pentagon.setStroke(Color.BLACK);
        pentagon.setStrokeWidth(2.0);

        for (int i = 0; i < 5; i++){
            double angle = Math.toRadians(90 + i * 72);
            pentagon.getPoints().addAll(
                centerX + radius * Math.cos(angle),
                centerY + radius * Math.sin(angle)
            );
        }
        PathTransition pt = new PathTransition();
        pt.setDuration(Duration.millis(4000));
        pt.setPath(pentagon);
        pt.setNode(r1);
        pt.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
        pt.setCycleCount(Timeline.INDEFINITE);
        pt.setAutoReverse(true);
        pt.play();

        pane.getChildren().addAll(pentagon, r1);
        Scene scene = new Scene(pane,300,250);
        primaryStage.setTitle("Exercise_15_Animation");
        primaryStage.setScene(scene);
        primaryStage.show();

        scene.setOnMouseClicked(e -> {
            if (pt.getStatus() == Timeline.Status.RUNNING) {
                pt.pause();
            } else {
                pt.play();
            }
        });
    }
}
