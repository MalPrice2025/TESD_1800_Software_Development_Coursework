import java.util.Date;
import java.util.Scanner;

public class account {
    public static void main(String[] agrs) {
        Scanner scan = new Scanner(System.in);
        int choice;
       
        accountMod[] accounts = new accountMod[10];
        for (int i = 0; i < accounts.length; i++) {
           accountMod baseAccount = new accountMod(i, 100.0);

           Checking checking = new Checking();
           checking.setID(i);
           checking.setBalance(100.0);

           Savings savings = new Savings();
           savings.setID(i);
           savings.setBalance(100.0);

           baseAccount.setChecking(checking);
           baseAccount.setSavings(savings);

           accounts[i] = baseAccount;
        }
        while (true) { 
            int userID;
            boolean match;

        do {
            System.out.println();
            System.out.println("Enter Account ID: ");
            userID = scan.nextInt();
            match = false;
                for (accountMod account : accounts) {
                    if (account.getID() == userID) {
                        match = true;
                        break;
                    }
                }
                if (!match) { System.out.println("Invalid -X- Please try again.");
                }
        }while (!match);

        do {
            System.out.println();
            System.out.println("---Main Menu---");
            System.out.println();
            System.out.println("Please Select One Of The Following.|");
            System.out.println("1) -Total Balance-                 |");
            System.out.println("2) -Checking Account-              |");
            System.out.println("3) -Savings Account-               |");
            System.out.println("4) -Exit-                          |");
            choice = scan.nextInt();

                switch (choice) {
                    case 1 -> System.out.println("Total Balance - " + accounts[userID].getBalance());
                    case 2 -> OpenChecking(accounts, userID);
                    case 3 -> OpenSavings(accounts, userID);
                    case 4 -> System.out.println("Exiting to Main");
                    default -> {
                    }
                }
        }while (choice != 4);
        }
    }
    static void OpenChecking(accountMod[] accounts, int userID) {
        Scanner scan = new Scanner(System.in);
        Checking checking = accounts[userID].getChecking();
        System.out.println("-Checking Account Details-");
        System.out.println("1) Withdraw");
        System.out.println("2) Deposit");
        int checkChoice = scan.nextInt();
        if (checkChoice == 1) { System.out.println("Enter Amount to Withdraw:");
        double amount = scan.nextDouble();
        checking.withdrawCheck(amount);
        } else if (checkChoice == 2) { System.out.println("Enter Amount to Deposit:");
        double amount = scan.nextDouble();
        checking.depositCheck(amount);
        }
        System.out.println("Updated Checking Account Balance: " + checking.getCheckBalance());
    }
    static void OpenSavings(accountMod[] accounts, int userID) {
        Scanner scan = new Scanner(System.in);
        Savings savings = accounts[userID].getSavings();
        System.out.println("-Savings Account Details-");
        System.out.println("1) Withdraw");
        System.out.println("2) Deposit");
        int saveChoice = scan.nextInt();
        if (saveChoice == 1) { System.out.println("Enter Amount to Withdraw:");
        double amount = scan.nextDouble();
        savings.withdraw(amount);
        } else if (saveChoice == 2) { System.out.println("Enter Amount to Deposit:");
        double amount = scan.nextDouble();
        savings.depositSave(amount);
        }
        System.out.println("Updated Savings Account Balance: " + savings.getSaveBalance());
    }
}
class accountMod {
    private int id;
    private double balance;
    private double annualInterestRate;
    private Date dateCreated;
    private Checking checkingAccount;
    private Savings savingsAccount;
    
   public accountMod() {
        id = 0;
        balance = 0.0;
        annualInterestRate = 0.0;
        dateCreated = new Date();
    }
    public accountMod(int newID, double newBalance) {
        id = newID;
        balance = newBalance;
        annualInterestRate = 0.0;
        dateCreated = new Date();
    }
    public Checking getChecking() {
        return checkingAccount;
    }
    public void setChecking(Checking checking) {
        this.checkingAccount = checking;
    }
    public Savings getSavings() {
        return savingsAccount;
    }
    public void setSavings(Savings savings) {
        this.savingsAccount = savings;
    }
    public Date getDate() {
        return dateCreated;
    }
    public void setDate(Date newdateCreated) {
        dateCreated = newdateCreated;
    }
    public int getID() {
        return id;
    }
    public void setID(int newID) {
        id = newID;
    }
    public double getBalance() {
        return balance;
    }
    public void setBalance(double newBalance) {
        balance = newBalance;
    }
    public double getAnnualInterestRate() {
        return annualInterestRate;
    }
    public void setAnnualInterestRate(double newAnnualInterestRate) {
        annualInterestRate = newAnnualInterestRate;
    }
    public double getMonthlyInterestRate() {
        return (annualInterestRate/100) /12;
    }
    public double getMonthlyInterest() {
        return balance * getMonthlyInterestRate();
    }
    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
        }
    }
    public void deposit(double amount) {
        balance = balance + amount;
    }
}
class Checking extends accountMod {
    private int id;
    @SuppressWarnings("unused")
    private double balance;

    public Checking() {
        id = 0;
        balance = 0.0;
    }
    public int getcheckID() {
        return id;
    }
    public void setcheckID(int newID) {
        id = newID;
    }
    public double getCheckBalance() {
        return getBalance();
    }
    public void setCheckBalance(double newBalance) {
        balance = newBalance;
    }
    public void withdrawCheck(double amount) {
        if (amount <= getBalance()) {
            setBalance(getBalance() - amount);
        } else { System.out.println("Insufficient Funds in Checking.");}
    }
    public void depositCheck(double amount) {
        setBalance(getBalance() + amount);
    }
}
class Savings extends accountMod {
    private int id;
    @SuppressWarnings("unused")
    private double balance;
    
    public Savings() {
        id = 0;
        balance = 0.0;
        }
    public int getSaveID() {
        return id;
    }
    public void setSaveID(int newID) {
        id = newID;
    }
    public double getSaveBalance() {
        return getBalance();
    }
    public void setSaveBalance(double newBalance) {
        balance = newBalance;
    }
    public void withdrawSave(double amount) {
        if (amount > getBalance()) { System.out.println("Withdrawl cancled. Amount " + amount + " is greater than account funds.");
        } else { setBalance(getBalance() - amount);
        }
    }
    public void depositSave(double amount) {
        setBalance(getBalance() + amount);
    }
}