import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter An Encrypted Input File Name: ");
        String inputFileName = scan.nextLine();
        File inputFile = new File(inputFileName);
        System.out.println("Enter A Unencrypted Output File Name: ");
        String outputFileName = scan.nextLine();
        File outputFile = new File(outputFileName);

        if (!inputFile.exists()){
            System.out.println("File Doesnt Exist Yet.");
            scan.close();
            return;
        }
        if (!outputFile.exists()) {
            outputFile.createNewFile();
        }
        try (
            FileInputStream input = new FileInputStream(inputFileName);
            FileOutputStream output = new FileOutputStream(outputFileName);
        ) {
            int value;
            while ((value = input.read()) != -1) {
                byte bt = (byte)(value - 5);
                output.write(bt);
            }
        }
        System.out.println("File Successfully Decrypted.");
        scan.close();
    }
}