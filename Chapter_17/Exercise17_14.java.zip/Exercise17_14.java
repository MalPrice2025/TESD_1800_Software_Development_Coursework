import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter An Input File Name: ");
        String inputFileName = scan.nextLine();
        File inputFile = new File(inputFileName);
        System.out.println("Enter An Output File Name: ");
        String outputFileName = scan.nextLine();
        File outputFile = new File(outputFileName);

        if (!inputFile.exists()) {
            inputFile.createNewFile();
        } 
        if (!outputFile.exists()) {
            outputFile.createNewFile();
        }
        try (FileOutputStream input = new FileOutputStream(inputFile)
        ) {
            for (int i = 0; i < 50; i++){
                input.write(i);
            }

        }
        try (FileInputStream input = new FileInputStream(inputFile);
            FileOutputStream output = new FileOutputStream(outputFile);
        ) {
            int value;
            while ((value = input.read()) != -1) {
                byte bt = (byte) (value + 5);
                output.write(bt);
            }
        }
        System.out.println("File Encrypted Successfully to " + outputFileName + ".");
        System.out.println("\nOutput File Path: " + outputFile.getAbsolutePath());
        scan.close();
    }
}