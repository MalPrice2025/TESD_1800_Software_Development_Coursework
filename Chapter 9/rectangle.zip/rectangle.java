public class rectangle {
    public static void main(String[] args) {
        simpleRectangle rectangle1 = new simpleRectangle(35.9,3.5);
        System.out.println("The width and height of this rectangle is " + rectangle1.width + ", " + rectangle1.height + ", and the area of the rectangle is " + rectangle1.getArea() + ", and the perimeter is " + rectangle1.getPerimeter() + ".");
        
        simpleRectangle rectangle2 = new simpleRectangle(40.0,4.0);
        System.out.println("The width and height of this rectangle is " + rectangle2.width + ", " + rectangle2.height + ", and the area of the rectangle 2 is " + rectangle2.getArea() + ", and the perimeter is " + rectangle2.getPerimeter() + ".");
    }
}
class simpleRectangle {
    double height;
    double width;

    simpleRectangle() {
        height = 1;
        width = 1;
    }
    simpleRectangle(double newHeight, double newWidth) {
        height = newHeight;
        width = newWidth;
    }
    double getArea() {
        return height * width;
    }
    double getPerimeter() {
        return 2 * (height + width);
    }
    void setWidthsetHeight(double newHeight, double newWidth) {
        width = newWidth;
        height = newHeight;
    }
}