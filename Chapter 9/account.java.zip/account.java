import java.util.*;

public class account {
    public static void main(String[] agrs) {
        
        accountMod account1 = new accountMod(1122, 20000.00);
        account1.setAnnualInterestRate(4.5);
        account1.withdraw(2500);
        account1.deposit(3000);
        
        System.out.println("Balance: $" + account1.getBalance() + ".");
        System.out.println("Monthly Interest: $" + account1.getMonthlyInterest() + ".");
        System.out.println("Date Created: " + account1.getDateCreated() + ".");
    }
}
class accountMod {
    private int id;
    private double balance;
    private double annualInterestRate;
    private Date dateCreated;
    
    accountMod() {
        id = 0;
        balance = 0.0;
        annualInterestRate = 0.0;
        dateCreated = new Date();
    }
    public accountMod(int newID, double newBalance) {
        id = newID;
        balance = newBalance;
        annualInterestRate = 0.0;
        dateCreated = new Date();
    }
    public int getID() {
        return id;
    }
    public void setID(int newID) {
        id = newID;
    }
    public double getBalance() {
        return balance;
    }
    public void setBalance(double newBalance) {
        balance = newBalance;
    }
    public double getAnnualInterestRate() {
        return annualInterestRate;
    }
    public void setAnnualInterestRate(double newAnnualInterestRate) {
        annualInterestRate = newAnnualInterestRate;
    }
    public Date getDateCreated() {
        return dateCreated;
    }
    public double getMonthlyInterestRate() {
        return (annualInterestRate/100) /12;
    }
    public double getMonthlyInterest() {
        return balance * getMonthlyInterestRate();
    }
    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
        }
    }
    public void deposit(double amount) {
        balance =+ amount;
    }
}
    