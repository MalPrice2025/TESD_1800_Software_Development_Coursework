import java.util.*;
import java.io.File;
import java.io.PrintWriter;

class testcode {
    public static void main(String[] args) throws Exception {
        File file = new File("Exercise12_15.txt");
        if (!(file.exists())) {
            PrintWriter output = new PrintWriter(file);
            for (int i = 0; i < 100; i++) {
                int randomNumber = (int) (Math.random() * 1000);
                output.print(randomNumber + " ");
            }
            output.close();
            System.out.println("All integers moved into Exercise12_15.");
        } else { 
            System.out.println("File already exists.");
            return;
        }
        Scanner scan = new Scanner(file);
        int[] numbers = new int[100];
        int count = 0;
        while (scan.hasNextInt()&& count < 100) {
            numbers[count++] = scan.nextInt();
            }
            scan.close();
            Arrays.sort(numbers);
            System.out.println("Exercise12_15 numbers in increasing order:");
            for (int i = 0; i < numbers.length; i++) {
                System.out.print(numbers[i] + " ");
                if ((i + 1) % 10 == 0) System.out.println();
            }
        }
    }
