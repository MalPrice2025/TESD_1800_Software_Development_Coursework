import java.util.*;

class TestCode{
    public static void main(String[] args){
     @SuppressWarnings("resource")
    Scanner scan = new Scanner(System.in);
     int[] numbers = new int[100];
     int index;
     for (int i = 0; i < numbers.length; i++) {
        numbers[i] =(int) (Math.random() * 1000);
     }
     while (true) {
        System.out.println();
        System.out.println("Enter 404 to stop.");
        System.out.println("Enter an index:");
        index = scan.nextInt();

        if (index == 404) {
            System.out.println("Stopping program...");
            break;
        }
     try {
        System.out.println("The corresponding element value for " + index + ", is " + numbers[index]);
     } catch (ArrayIndexOutOfBoundsException ex) {
        System.out.println("Out of Bounds.");
    }
}
    }
}