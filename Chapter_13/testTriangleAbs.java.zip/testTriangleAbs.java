import java.util.*;

public class testTriangle {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        Triangle triangle = new Triangle();
        boolean filled;
        System.out.println("What color would you like?");
        String colorr = scan.nextLine();
        triangle.setColor(colorr);
        System.out.println();
        System.out.println("Is the triangle filled?");
        String yn = scan.nextLine();
        System.out.println();
        if (yn.equalsIgnoreCase("yes")|| yn.equalsIgnoreCase("yeah")) {
            filled = true;} 
            else {
            filled = false;}
            triangle.setFilled(filled);
        System.out.println("Enter the lengths for the triangles sides:");
        double sideO = scan.nextDouble();
        double sideT = scan.nextDouble();
        double sideTH = scan.nextDouble();
        System.out.println();
        triangle.setSide1(sideO);
        triangle.setSide2(sideT);
        triangle.setSide3(sideTH);
        System.out.println(triangle.toString());
        System.out.println("Triangle area: " +triangle.getArea());
        System.out.println("Triangle perimeter: " +triangle.getPerimeter());

    scan.close();
    }
}
abstract class GeometricObject{
    private String color;
    private boolean filled;

    public GeometricObject(String color, boolean filled){
        this.color = color;
        this.filled = filled;
    }
    public String getColor(){
        return color;
    }
    public void setColor(String color){
        this.color = color;
    }
    public boolean getFilled(){
        return filled;
    }
    public void setFilled(boolean filled){
        this.filled = filled;
    }
    public String toString(){
        return"\nColor: " +color+ "\nfilled: " +filled;
    }
    public abstract double getArea();
    public abstract double getPerimeter();
}
class Triangle extends GeometricObject{
    private double side1;
    private double side2;
    private double side3;

    public Triangle(){
        super("white", false);
        side1 = 1.0;
        side2 = 1.0;
        side3 = 1.0;
    }
    public Triangle(double side1, double side2, double side3, String color, boolean filled){
        super(color,filled);
        side1 = this.side1;
        side2 = this.side2;
        side3 = this.side3;
    }
    public double getSide1(){
        return side1;
    }
    public double getSide2(){
        return side2;
    }
    public double getSide3(){
        return side3;
    }
    public void setSide1(double side1){
        this.side1 = side1;
    }
    public void setSide2(double side2){
        this.side2 = side2;
    }
    public void setSide3(double side3){
        this.side3 = side3;
    }
    public double getPerimeter(){
        return side1+side2+side3;
    }
    public double getArea(){
        double s = getPerimeter() / 2;
        return Math.sqrt(s*(s-side1)*(s-side2)*(s-side3));
    }
    public String toString(){
        return "Triangle: side 1 = " +side1+ ", side 2 = " +side2+ ", side 3 = " +side3 + super.toString();
    }
}