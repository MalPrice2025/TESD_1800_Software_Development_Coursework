import java.util.*;

class testOct{
    @SuppressWarnings("resource")
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        Oct oct = new Oct();
        System.out.println("Enter the color for your octagon:");
        String colorr = scan.nextLine();
        oct.setColor(colorr);

        System.out.println("Is the octagon filled?");
        String yon = scan.nextLine();
        if(yon.equalsIgnoreCase("Yes")|| yon.equalsIgnoreCase("yeah")) {
            oct.setFilled(true);
        } else { oct.setFilled(false); }

        try {
        System.out.println("Enter the side length for your octagon:");
        double sideL = scan.nextDouble();
        if (sideL <= 0) { System.out.println("Side length must be positive.");
        return;
        } oct.setSides(sideL);
        } catch(InputMismatchException ex) { System.out.println("Invalid input for side length."); }
        Oct oct2 = oct.clone();

        System.out.println("Octagon 1: " +oct);
        System.out.println("Clone Octagon: " +oct2);
        int compare = oct.compareTo(oct2);
        if(compare < 0) { System.out.println("Octagon 1 is smaller than the clone."); }
        else if (compare > 0) { System.out.println("Octagon 1 is bigger than the clone."); }
        else { System.out.println("Octagon 1 and the clone are equal."); }
    }
}
abstract class GeoObj{
    private String color;
    private boolean filled;

    public GeoObj(){
        color = "White";
        filled = false;
    }
    public GeoObj(String color, boolean filled){
        this.color = color;
        this.filled = filled;
    }
    public String getColor(){
        return color;
    }
    public boolean getFilled(){
        return filled;
    }
    public void setColor(String color){
        this.color = color;
    }
    public void setFilled(boolean filled){
        this.filled = filled;
    }
    public String toString(){
        return "\nColor: " +color+ "\nFilled: " +filled;
    }
    public abstract double getArea();
    public abstract double getPerimeter();
}
class Oct extends GeoObj implements Colorable, Cloneable, Comparable<Oct>{
    private double sides;

    public Oct(){
        super();
        sides = 1.0;
    }
    public Oct(double sides, String color, boolean filled){
        super("White", false);
        this.sides = sides;
    }
    public double getSides(){
        return sides;
    }
    public void setSides(double sides){
        this.sides = sides;
    }
    public double getArea(){
        return 2 *(1 + Math.sqrt(2)) * Math.pow(sides, 2);
    }
    public double getPerimeter(){
        return 8 * sides;
    }
    public void howToColor(){
        System.out.println("Color all 8 sides.");
    }
    public Oct clone() {
        Oct oct2 = new Oct();
        oct2.setSides(this.sides);
        oct2.setColor(this.getColor());
        oct2.setFilled(this.getFilled());
        return oct2;
    }
    public int compareTo(Oct other) {
        double area = this.getArea();
        double area2 = other.getArea();
        return Double.compare(area, area2);
    }
    public String toString(){
        return "Octagon: Side Length: " +sides+ super.toString();
    }
}
interface Colorable{
    public void howToColor();
}